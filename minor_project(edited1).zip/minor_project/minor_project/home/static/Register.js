function resetting(){
    document.form.reset();
  }